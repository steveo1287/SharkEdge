# SharkEdge elite refresh pack

Drop these files into the matching `frontend/` paths in your repo.

Included files:
- `frontend/app/board/page.tsx`
- `frontend/app/trends/page.tsx`
- `frontend/app/globals.css`
- `frontend/components/layout/app-shell.tsx`
- `frontend/components/board/board-command-center.tsx`
- `frontend/components/charts/mini-history-chart.tsx`
- `frontend/components/charts/metric-bar-chart.tsx`
- `frontend/components/intelligence/league-pulse-grid.tsx`
- `frontend/components/trends/trend-command-center.tsx`
- `frontend/lib/utils/team-branding.ts`

What this pack changes:
- rebuilds the board into a true command-center layout
- attaches standings, scoreboard history, and news to board/trends
- adds trend cards that sit next to board context instead of floating alone
- adds graph components for movement and league pulse
- adds team/logo helpers using ESPN ids already present in seed data
- refreshes shell styling and global visual language

After copying:
1. apply the earlier weather type fix in `frontend/lib/trends/context-variables.ts`
2. run `npm run build`
3. fix any new type breaks caused by unrelated existing repo debt
