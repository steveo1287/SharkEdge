import Link from "next/link";

import type { EliteGameCardModel } from "@/app/_components/home/home-card-adapter";

type EliteGameCardProps = {
  card: EliteGameCardModel;
  compact?: boolean;
};

function formatStartTime(value: string | null): string {
  if (!value) return "TBD";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "TBD";

  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit"
  });
}

function getStateTone(state: EliteGameCardModel["state"]) {
  switch (state) {
    case "LIVE":
      return "border-emerald-400/30 bg-emerald-500/10 text-emerald-200";
    case "FINAL":
      return "border-slate-500/20 bg-slate-500/10 text-slate-300";
    default:
      return "border-sky-400/25 bg-sky-500/10 text-sky-200";
  }
}

function getEdgeTone(edgePercent: number | null) {
  if (edgePercent == null) return "text-slate-400";
  if (edgePercent >= 3) return "text-emerald-300";
  if (edgePercent >= 1.5) return "text-sky-300";
  return "text-amber-300";
}

function TeamLogo({
  src,
  alt,
  fallback
}: {
  src: string | null;
  alt: string;
  fallback: string;
}) {
  if (!src) {
    return (
      <div className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-xs font-bold text-white">
        {fallback}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      className="h-10 w-10 rounded-full border border-white/10 bg-white object-contain p-1"
      loading="lazy"
    />
  );
}

export function EliteGameCard({ card, compact = false }: EliteGameCardProps) {
  return (
    <Link
      href={card.href}
      className="group rounded-[1.4rem] border border-white/8 bg-[#08111d]/95 p-4 shadow-[0_20px_50px_rgba(0,0,0,0.25)] transition hover:border-sky-400/30 hover:bg-[#0b1524]"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[0.66rem] uppercase tracking-[0.22em] text-slate-500">
            {card.league ?? "Game"}
          </div>
          <div className="mt-1 flex items-center gap-2">
            <span
              className={`rounded-full border px-2.5 py-1 text-[0.62rem] font-semibold uppercase tracking-[0.18em] ${getStateTone(card.state)}`}
            >
              {card.state}
            </span>
            <span className="text-xs text-slate-400">{formatStartTime(card.startTime)}</span>
          </div>
        </div>

        {card.edgePercent != null ? (
          <div className={`text-right text-sm font-semibold ${getEdgeTone(card.edgePercent)}`}>
            +{card.edgePercent.toFixed(1)}%
            <div className="mt-1 text-[0.62rem] uppercase tracking-[0.16em] text-slate-500">
              Edge
            </div>
          </div>
        ) : (
          <div className="text-right text-sm text-slate-500">No edge</div>
        )}
      </div>

      <div className="mt-4 grid gap-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex min-w-0 items-center gap-3">
            <TeamLogo
              src={card.awayTeam.logoUrl}
              alt={card.awayTeam.name}
              fallback={card.awayTeam.abbreviation}
            />
            <div className="min-w-0">
              <div className="truncate text-sm font-semibold text-white">
                {card.awayTeam.name}
              </div>
              <div className="text-xs uppercase tracking-[0.16em] text-slate-500">
                {card.awayTeam.abbreviation}
              </div>
            </div>
          </div>

          <div className="text-lg font-bold text-white">{card.awayScore ?? "-"}</div>
        </div>

        <div className="flex items-center justify-between gap-4">
          <div className="flex min-w-0 items-center gap-3">
            <TeamLogo
              src={card.homeTeam.logoUrl}
              alt={card.homeTeam.name}
              fallback={card.homeTeam.abbreviation}
            />
            <div className="min-w-0">
              <div className="truncate text-sm font-semibold text-white">
                {card.homeTeam.name}
              </div>
              <div className="text-xs uppercase tracking-[0.16em] text-slate-500">
                {card.homeTeam.abbreviation}
              </div>
            </div>
          </div>

          <div className="text-lg font-bold text-white">{card.homeScore ?? "-"}</div>
        </div>
      </div>

      <div className="terminal-rule mt-4" />

      <div className={`mt-4 grid ${compact ? "gap-2" : "gap-3"}`}>
        <div className="flex items-center justify-between gap-3">
          <div className="text-[0.68rem] uppercase tracking-[0.18em] text-slate-500">
            Best line
          </div>
          <div className="text-right text-sm font-medium text-white">
            {card.bestLineLabel ?? "Market context loading"}
          </div>
        </div>

        <div className="flex items-center justify-between gap-3">
          <div className="text-[0.68rem] uppercase tracking-[0.18em] text-slate-500">
            Confidence
          </div>
          <div className="text-sm font-medium text-slate-200">
            {card.confidenceLabel ?? "Unrated"}
          </div>
        </div>

        <div className="rounded-[1rem] border border-white/8 bg-white/[0.03] px-3 py-3 text-sm leading-6 text-slate-300">
          {card.reasonSummary ?? "No clear betting reason surfaced yet."}
        </div>
      </div>
    </Link>
  );
}
