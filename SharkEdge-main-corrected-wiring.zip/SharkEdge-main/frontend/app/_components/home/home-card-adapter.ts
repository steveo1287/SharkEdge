import type { BoardMarketView, GameCardView, LeagueKey } from "@/lib/types/domain";
import type { OpportunityView } from "@/lib/types/opportunity";
import { getTeamLogoUrl } from "@/lib/utils/entity-routing";

export type EliteGameCardModel = {
  id: string;
  href: string;
  startTime: string | null;
  state: "LIVE" | "UPCOMING" | "FINAL";
  awayTeam: {
    name: string;
    abbreviation: string;
    logoUrl: string | null;
  };
  homeTeam: {
    name: string;
    abbreviation: string;
    logoUrl: string | null;
  };
  awayScore: number | null;
  homeScore: number | null;
  league: string | null;
  bestLineLabel: string | null;
  edgePercent: number | null;
  confidenceLabel: string | null;
  reasonSummary: string | null;
};

export type SimpleGameCardModel = {
  id: string;
  homeTeam: string;
  awayTeam: string;
  homeScore?: number | null;
  awayScore?: number | null;
  commenceTime: string;
  edge?: number | null;
  confidence?: string | null;
  bestLine?: string | null;
  reason?: string | null;
  completed?: boolean;
  status?: string;
};

type TeamFallback = {
  name: string;
  abbreviation: string;
  logoUrl: string | null;
};

function resolveState(input: {
  startTime?: string | null;
  status?: string | null;
}): EliteGameCardModel["state"] {
  if (input.status === "FINAL") return "FINAL";
  if (input.status === "LIVE") return "LIVE";
  if (!input.startTime) return "UPCOMING";

  const start = new Date(input.startTime).getTime();
  if (Number.isNaN(start)) return "UPCOMING";

  const now = Date.now();
  if (start > now) return "UPCOMING";

  const fourHours = 4 * 60 * 60 * 1000;
  return now - start <= fourHours ? "LIVE" : "FINAL";
}

function formatOddsAmerican(value: number | null | undefined) {
  if (typeof value !== "number" || value === 0) return null;
  return value > 0 ? `+${value}` : `${value}`;
}

function formatConfidenceLabel(value: string | null | undefined) {
  if (!value) return null;
  const normalized = value.toUpperCase();
  if (normalized === "HIGH") return "High";
  if (normalized === "MEDIUM") return "Medium";
  if (normalized === "LOW") return "Low";
  if (normalized === "PASS") return "Pass";
  if (normalized === "A") return "Tier A";
  if (normalized === "B") return "Tier B";
  if (normalized === "C") return "Tier C";
  if (normalized === "D") return "Tier D";
  return value;
}

function getMarketEdgePercent(market: BoardMarketView) {
  return market.evProfile?.edgePct ?? null;
}

function getBestMarket(game: GameCardView) {
  const markets = [
    { key: "moneyline", label: "Moneyline", market: game.moneyline },
    { key: "spread", label: "Spread", market: game.spread },
    { key: "total", label: "Total", market: game.total }
  ] as const;

  return [...markets].sort((left, right) => {
    const edgeDelta = (getMarketEdgePercent(right.market) ?? -999) - (getMarketEdgePercent(left.market) ?? -999);
    if (edgeDelta !== 0) return edgeDelta;

    const confidenceDelta = (right.market.confidenceScore ?? -999) - (left.market.confidenceScore ?? -999);
    if (confidenceDelta !== 0) return confidenceDelta;

    return Math.abs(right.market.movement) - Math.abs(left.market.movement);
  })[0];
}

function getMarketReason(market: BoardMarketView) {
  const firstReason = market.reasons?.[0];
  if (firstReason?.detail?.trim()) return firstReason.detail.trim();
  if (firstReason?.label?.trim()) return firstReason.label.trim();
  if (market.marketTruth?.note?.trim()) return market.marketTruth.note.trim();
  return null;
}

function formatBestLineLabel(label: string, market: BoardMarketView) {
  if (market.lineLabel?.trim()) {
    return `${label}: ${market.lineLabel.trim()}`;
  }

  if (market.label?.trim()) {
    return `${label}: ${market.label.trim()}`;
  }

  const odds = formatOddsAmerican(market.bestOdds);
  return odds ? `${label}: ${odds}` : null;
}

function parseEventLabel(eventLabel: string) {
  const normalized = eventLabel.replace(/\s+vs\.?\s+/i, " @ ");
  const [awayRaw, homeRaw] = normalized.split(" @ ");

  return {
    away: awayRaw?.trim() || "Away",
    home: homeRaw?.trim() || "Home"
  };
}

function teamFromGame(leagueKey: LeagueKey, game: GameCardView, side: "away" | "home"): TeamFallback {
  const team = side === "away" ? game.awayTeam : game.homeTeam;
  return {
    name: team.name,
    abbreviation: team.abbreviation,
    logoUrl: getTeamLogoUrl(leagueKey, team)
  };
}

export function shouldShowOnMainSlate(card: EliteGameCardModel): boolean {
  if (card.state === "LIVE" || card.state === "UPCOMING") return true;
  if (card.state !== "FINAL" || !card.startTime) return false;

  const startedAt = new Date(card.startTime).getTime();
  if (Number.isNaN(startedAt)) return false;

  const twelveHours = 12 * 60 * 60 * 1000;
  return Date.now() - startedAt <= twelveHours;
}

export function mapVerifiedGameToEliteCard(
  game: GameCardView,
  league?: string | null
): EliteGameCardModel {
  const bestMarket = getBestMarket(game);

  return {
    id: game.id,
    href: game.detailHref ?? `/game/${game.id}`,
    startTime: game.startTime ?? null,
    state: resolveState({
      startTime: game.startTime,
      status: game.status
    }),
    awayTeam: teamFromGame(game.leagueKey, game, "away"),
    homeTeam: teamFromGame(game.leagueKey, game, "home"),
    awayScore: null,
    homeScore: null,
    league: league ?? game.leagueKey,
    bestLineLabel: formatBestLineLabel(bestMarket.label, bestMarket.market),
    edgePercent: getMarketEdgePercent(bestMarket.market),
    confidenceLabel: formatConfidenceLabel(bestMarket.market.confidenceBand ?? game.edgeScore.label),
    reasonSummary:
      getMarketReason(bestMarket.market) ??
      `${bestMarket.label} is the cleanest current angle across the verified board row.`
  };
}

export function mapActionableToEliteCard(
  opportunity: OpportunityView,
  relatedGame?: GameCardView | null
): EliteGameCardModel | null {
  const fallback = parseEventLabel(opportunity.eventLabel);

  const awayTeam = relatedGame
    ? teamFromGame(relatedGame.leagueKey, relatedGame, "away")
    : {
        name: fallback.away,
        abbreviation: fallback.away
          .split(" ")
          .map((part) => part[0])
          .join("")
          .slice(0, 3)
          .toUpperCase() || "AWY",
        logoUrl: null
      };

  const homeTeam = relatedGame
    ? teamFromGame(relatedGame.leagueKey, relatedGame, "home")
    : {
        name: fallback.home,
        abbreviation: fallback.home
          .split(" ")
          .map((part) => part[0])
          .join("")
          .slice(0, 3)
          .toUpperCase() || "HME",
        logoUrl: null
      };

  const displayedOdds = formatOddsAmerican(opportunity.displayOddsAmerican);
  const displayLine = opportunity.displayLine == null ? null : String(opportunity.displayLine);
  const bestLineLabel = [opportunity.selectionLabel, displayLine, displayedOdds].filter(Boolean).join(" • ");

  return {
    id: opportunity.id,
    href: relatedGame?.detailHref ?? `/game/${relatedGame?.id ?? opportunity.eventId}`,
    startTime: relatedGame?.startTime ?? null,
    state: resolveState({
      startTime: relatedGame?.startTime ?? null,
      status: relatedGame?.status ?? null
    }),
    awayTeam,
    homeTeam,
    awayScore: null,
    homeScore: null,
    league: opportunity.league ?? relatedGame?.leagueKey ?? null,
    bestLineLabel: bestLineLabel || null,
    edgePercent: opportunity.expectedValuePct ?? opportunity.modelEdgePercent ?? null,
    confidenceLabel: formatConfidenceLabel(opportunity.confidenceTier),
    reasonSummary: opportunity.reasonSummary ?? opportunity.triggerSummary ?? null
  };
}

export function mapGameToCard(game: GameCardView): SimpleGameCardModel {
  const bestMarket = getBestMarket(game);

  return {
    id: game.id,
    homeTeam: game.homeTeam.name,
    awayTeam: game.awayTeam.name,
    homeScore: null,
    awayScore: null,
    commenceTime: game.startTime,
    bestLine: formatBestLineLabel(bestMarket.label, bestMarket.market),
    edge: getMarketEdgePercent(bestMarket.market),
    confidence: formatConfidenceLabel(bestMarket.market.confidenceBand ?? game.edgeScore.label),
    reason: getMarketReason(bestMarket.market) ?? undefined,
    completed: game.status === "FINAL",
    status: game.status
  };
}
