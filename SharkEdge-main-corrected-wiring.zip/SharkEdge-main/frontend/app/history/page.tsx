import { EliteGameCard } from "@/components/home/elite-game-card";
import { Card } from "@/components/ui/card";
import { SectionTitle } from "@/components/ui/section-title";
import {
  mapVerifiedGameToEliteCard,
  shouldShowOnMainSlate
} from "@/app/_components/home/home-card-adapter";
import { getHomeCommandData } from "@/services/home/home-command-service";

export const dynamic = "force-dynamic";

export default async function HistoryPage() {
  const home = await getHomeCommandData({});
  const finalCards = home.boardData.games
    .map((game) => mapVerifiedGameToEliteCard(game, home.focusedLeague))
    .filter((card) => card.state === "FINAL" && !shouldShowOnMainSlate(card))
    .slice(0, 24);

  return (
    <div className="grid gap-6">
      <SectionTitle
        eyebrow="Archive"
        title="Recent finals"
        description="Closed games live here instead of cluttering the active homepage."
      />

      {finalCards.length ? (
        <div className="grid gap-4 xl:grid-cols-2">
          {finalCards.map((card) => (
            <EliteGameCard key={card.id} card={card} compact />
          ))}
        </div>
      ) : (
        <Card className="surface-panel p-6 text-sm leading-7 text-slate-400">
          No recent finals are available in history.
        </Card>
      )}
    </div>
  );
}
